import React from "react";
import "./style.css";

export const FrameScreen = () => {
  return (
    <div className="frame-screen">
      <div className="frame-2" />
    </div>
  );
};
