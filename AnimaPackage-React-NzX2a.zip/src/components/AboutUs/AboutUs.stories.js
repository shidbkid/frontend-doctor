import { AboutUs } from ".";

export default {
  title: "Components/AboutUs",
  component: AboutUs,
};

export const Default = {
  args: {
    className: {},
    text: "About Us",
  },
};
